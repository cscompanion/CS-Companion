﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewsAPI.Models
{
    public class Source
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
